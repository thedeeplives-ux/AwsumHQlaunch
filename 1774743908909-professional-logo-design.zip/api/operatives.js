// Vercel Serverless Function — /api/operatives
// Admin endpoint: exports operative database as CSV
//
// Protected by ADMIN_SECRET env var.
// Usage: GET /api/operatives?key=YOUR_ADMIN_SECRET
// Optional: &format=json for JSON output (default: CSV)
//
// Required env vars:
//   SUPABASE_URL   — your Supabase project URL
//   SUPABASE_KEY   — your Supabase service/anon key
//   ADMIN_SECRET   — secret key for admin access (set any strong string)

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ status: 'error', message: 'method not recognized.' });
  }

  // ── Auth gate ──
  const ADMIN_SECRET = process.env.ADMIN_SECRET;
  const providedKey = req.query.key || req.headers['x-admin-key'];

  if (!ADMIN_SECRET) {
    return res.status(500).json({ 
      status: 'error', 
      message: 'admin access not configured. set ADMIN_SECRET env var.' 
    });
  }

  if (!providedKey || providedKey !== ADMIN_SECRET) {
    // Intentionally vague — deny existence of this endpoint
    return res.status(404).json({ 
      status: 'error', 
      message: 'signal not found. frequency unknown.' 
    });
  }

  // ── Database connection ──
  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SUPABASE_KEY = process.env.SUPABASE_KEY;

  if (!SUPABASE_URL || !SUPABASE_KEY) {
    return res.status(500).json({ 
      status: 'error', 
      message: 'backend not configured.' 
    });
  }

  try {
    // Fetch all operatives ordered by registration date
    const response = await fetch(
      `${SUPABASE_URL}/rest/v1/operatives?select=id,email,ip,user_agent,created_at&order=created_at.desc&limit=10000`,
      {
        headers: {
          'apikey': SUPABASE_KEY,
          'Authorization': `Bearer ${SUPABASE_KEY}`
        }
      }
    );

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(errText);
    }

    const operatives = await response.json();
    const format = req.query.format || 'csv';

    // ── JSON output ──
    if (format === 'json') {
      return res.status(200).json({
        status: 'ok',
        count: operatives.length,
        exported_at: new Date().toISOString(),
        operatives
      });
    }

    // ── CSV output (default) ──
    const csvHeader = 'id,email,ip,user_agent,created_at';
    const csvRows = operatives.map(op => {
      const escape = (val) => {
        const str = String(val || '');
        // Wrap in quotes if it contains commas, quotes, or newlines
        if (str.includes(',') || str.includes('"') || str.includes('\n')) {
          return `"${str.replace(/"/g, '""')}"`;
        }
        return str;
      };
      return [op.id, escape(op.email), escape(op.ip), escape(op.user_agent), op.created_at].join(',');
    });

    const csv = [csvHeader, ...csvRows].join('\n');

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="awsum-operatives-${Date.now()}.csv"`);
    return res.status(200).send(csv);

  } catch (err) {
    console.error('Operatives export error:', err);
    return res.status(500).json({ 
      status: 'error', 
      message: 'database extraction failed.' 
    });
  }
}