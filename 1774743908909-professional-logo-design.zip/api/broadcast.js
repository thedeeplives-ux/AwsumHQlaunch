// Vercel Serverless Function — /api/broadcast
// Sends encrypted-themed "ARCHIVE UNLOCKED" email blast to all operatives
//
// Protected by ADMIN_SECRET env var.
// Usage: POST /api/broadcast
//   Headers: x-admin-key: YOUR_ADMIN_SECRET
//   Body (optional): { "subject": "custom subject", "preview": "preview text" }
//
// Modes:
//   LIVE:      POST { }                                    → sends to all operatives
//   DRY RUN:   POST { "dry_run": true }                    → simulates, sends nothing
//   TEST SEND: POST { "test_send": "you@awsum.ai" }       → sends one real email to specified address
//
// Test send verifies:
//   — Resend API key + sender domain are working
//   — Email renders correctly in Gmail, Apple Mail, Outlook
//   — Subject line, preview text, CTA all functional
//   — No operatives are contacted
//
// Required env vars:
//   SUPABASE_URL   — your Supabase project URL
//   SUPABASE_KEY   — your Supabase service/anon key
//   ADMIN_SECRET   — secret key for admin access
//   RESEND_API_KEY — API key from resend.com
//   BROADCAST_FROM — verified sender (e.g. "AWSUM <signal@awsum.ai>")
//
// Setup:
//   1. Create free account at resend.com
//   2. Verify your domain (awsum.ai)
//   3. Get API key from dashboard
//   4. Add RESEND_API_KEY and BROADCAST_FROM to Vercel env vars

const DEFAULT_SUBJECT = '▓▓▓ ARCHIVE UNLOCKED ▓▓▓ CLEARANCE GRANTED';
const DEFAULT_PREVIEW = 'The suppression ends now. Access the archive.';

function generateEmail(email, operativeId) {
  return `
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin:0;padding:0;background:#000;font-family:'Courier New',monospace;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#000;min-height:100vh;">
<tr><td align="center" style="padding:40px 20px;">
<table width="600" cellpadding="0" cellspacing="0" style="background:#0a0a0a;border:1px solid #0f2;max-width:600px;">

<!-- Header scan line -->
<tr><td style="height:2px;background:linear-gradient(90deg,transparent,#0f2,transparent);"></td></tr>

<!-- Classification banner -->
<tr><td style="padding:20px 30px 10px;text-align:center;">
  <span style="color:#0f2;font-size:10px;letter-spacing:6px;border:1px solid #0f233;padding:4px 12px;">◼ CLASSIFIED TRANSMISSION ◼</span>
</td></tr>

<!-- AWSUM Logo -->
<tr><td style="padding:30px 30px 5px;text-align:center;">
  <span style="color:#0f2;font-size:36px;letter-spacing:12px;font-weight:bold;">AWSUM</span>
</td></tr>
<tr><td style="padding:0 30px 20px;text-align:center;">
  <span style="color:#0f2aa;font-size:11px;letter-spacing:4px;">PHENOMENA HEADQUARTERS</span>
</td></tr>

<!-- Divider -->
<tr><td style="padding:0 30px;">
  <table width="100%" cellpadding="0" cellspacing="0"><tr>
    <td style="height:1px;background:#0f2;opacity:0.3;"></td>
  </tr></table>
</td></tr>

<!-- Main message -->
<tr><td style="padding:30px;">
  <p style="color:#0f2;font-size:13px;line-height:1.8;margin:0 0 15px;">
    &gt; ARCHIVE STATUS: <span style="color:#fff;background:#0f2;padding:2px 8px;font-weight:bold;">UNLOCKED</span>
  </p>
  <p style="color:#0f299;font-size:12px;line-height:1.8;margin:0 0 15px;">
    Operative,
  </p>
  <p style="color:#0f2cc;font-size:12px;line-height:2;margin:0 0 20px;">
    The gatekeepers failed. Suppression protocols have been neutralized.
    Every signal they buried. Every frequency they jammed. Every file they
    redacted. Now declassified. Now accessible. Now yours.
  </p>
  <p style="color:#0f2cc;font-size:12px;line-height:2;margin:0 0 25px;">
    Your coordinates were logged. Your clearance is confirmed.
    The archive is open.
  </p>

  <!-- CTA Button -->
  <table width="100%" cellpadding="0" cellspacing="0"><tr><td align="center">
    <a href="https://awsum.ai/archive" style="display:inline-block;background:#0f2;color:#000;font-family:'Courier New',monospace;font-size:13px;font-weight:bold;letter-spacing:3px;padding:14px 40px;text-decoration:none;border:none;">
      ▸ ACCESS THE ARCHIVE ▸
    </a>
  </td></tr></table>
</td></tr>

<!-- Divider -->
<tr><td style="padding:0 30px;">
  <table width="100%" cellpadding="0" cellspacing="0"><tr>
    <td style="height:1px;background:#0f2;opacity:0.3;"></td>
  </tr></table>
</td></tr>

<!-- Metadata footer -->
<tr><td style="padding:20px 30px;">
  <p style="color:#0f244;font-size:9px;line-height:1.8;margin:0;">
    OPERATIVE: ${email}<br>
    CLEARANCE: LEVEL 7<br>
    TRANSMISSION ID: ${operativeId || 'UNKNOWN'}<br>
    TIMESTAMP: ${new Date().toISOString()}<br>
    ENCRYPTION: AES-256-GCM
  </p>
</td></tr>

<!-- Classification footer -->
<tr><td style="padding:10px 30px 20px;text-align:center;">
  <span style="color:#0f233;font-size:8px;letter-spacing:4px;">THIS SIGNAL WILL NOT REPEAT</span>
</td></tr>

<!-- Bottom scan line -->
<tr><td style="height:2px;background:linear-gradient(90deg,transparent,#0f2,transparent);"></td></tr>

</table>

<!-- Unsubscribe -->
<p style="text-align:center;margin:20px 0 0;">
  <a href="https://awsum.ai/unsubscribe?id=${operativeId}" style="color:#0f244;font-size:9px;text-decoration:underline;">disconnect from network</a>
</p>

</td></tr>
</table>
</body>
</html>`.trim();
}

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-admin-key');

  if (req.method === 'OPTIONS') return res.status(200).end();

  if (req.method !== 'POST') {
    return res.status(405).json({ status: 'error', message: 'method not recognized.' });
  }

  // ── Auth gate ──
  const ADMIN_SECRET = process.env.ADMIN_SECRET;
  const providedKey = req.headers['x-admin-key'] || req.body?.key;

  if (!ADMIN_SECRET || !providedKey || providedKey !== ADMIN_SECRET) {
    return res.status(404).json({ status: 'error', message: 'signal not found. frequency unknown.' });
  }

  // ── Env check ──
  const { SUPABASE_URL, SUPABASE_KEY, RESEND_API_KEY, BROADCAST_FROM } = process.env;

  if (!SUPABASE_URL || !SUPABASE_KEY) {
    return res.status(500).json({ status: 'error', message: 'database not configured.' });
  }
  const subject = req.body?.subject || DEFAULT_SUBJECT;
  const preview = req.body?.preview || DEFAULT_PREVIEW;
  const dryRun = req.body?.dry_run === true;
  const testSend = req.body?.test_send || null;

  // Validate test_send email if provided
  if (testSend && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(testSend)) {
    return res.status(400).json({ status: 'error', message: 'test_send address malformed. verify coordinates.' });
  }

  // Resend config required for live broadcast and test sends, not dry runs
  if (!dryRun && !RESEND_API_KEY) {
    return res.status(500).json({ status: 'error', message: 'transmission relay not configured. set RESEND_API_KEY.' });
  }
  if (!dryRun && !BROADCAST_FROM) {
    return res.status(500).json({ status: 'error', message: 'sender frequency not configured. set BROADCAST_FROM.' });
  }

  try {
    // ── Fetch all operatives ──
    const dbRes = await fetch(
      `${SUPABASE_URL}/rest/v1/operatives?select=id,email,created_at&order=created_at.asc&limit=10000`,
      {
        headers: {
          'apikey': SUPABASE_KEY,
          'Authorization': `Bearer ${SUPABASE_KEY}`
        }
      }
    );

    if (!dbRes.ok) throw new Error(await dbRes.text());
    const operatives = await dbRes.json();

    if (operatives.length === 0) {
      return res.status(200).json({
        status: 'empty',
        message: 'no operatives in the network. broadcast aborted.',
        sent: 0, failed: 0
      });
    }

    // ── Dry run — simulate without sending ──
    if (dryRun) {
      const sampleOp = operatives[0];
      const previewHtml = generateEmail(sampleOp.email, sampleOp.id);
      const emails = operatives.map(op => op.email);

      const batchCount = Math.ceil(operatives.length / 50);
      const estimatedSeconds = batchCount * 1.1;

      return res.status(200).json({
        status: 'dry_run',
        message: `simulation complete. ${operatives.length} operatives would receive transmission. zero signals sent.`,
        operatives: {
          total: operatives.length,
          list: emails,
          first_recruited: operatives[0]?.created_at || null,
          last_recruited: operatives[operatives.length - 1]?.created_at || null
        },
        broadcast: {
          subject: subject,
          from: BROADCAST_FROM,
          batches: batchCount,
          estimated_duration: `~${Math.ceil(estimatedSeconds)}s`
        },
        email_preview: {
          html: previewHtml,
          recipient: sampleOp.email,
          note: 'preview generated for first operative. all emails are personalized with operative-specific metadata.'
        },
        timestamp: new Date().toISOString()
      });
    }

    // ── Test send — one real email to a specified address ──
    if (testSend) {
      const html = generateEmail(testSend, 'TEST-000');
      const plainText = `ARCHIVE UNLOCKED. Suppression protocols neutralized. Access: https://awsum.ai/archive — Test operative ${testSend}, Clearance Level 7.`;

      try {
        const sendRes = await fetch('https://api.resend.com/emails', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${RESEND_API_KEY}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            from: BROADCAST_FROM,
            to: [testSend],
            subject: `[TEST] ${subject}`,
            html: html,
            text: plainText,
            headers: {
              'X-Entity-Ref-ID': `awsum-test-${Date.now()}`
            },
            tags: [
              { name: 'campaign', value: 'archive-unlock-test' },
              { name: 'type', value: 'test_send' }
            ]
          })
        });

        if (!sendRes.ok) {
          const errBody = await sendRes.text();
          return res.status(500).json({
            status: 'test_failed',
            message: `test transmission failed to ${testSend}.`,
            error: errBody,
            timestamp: new Date().toISOString()
          });
        }

        const sendData = await sendRes.json();

        return res.status(200).json({
          status: 'test_transmitted',
          message: `test signal sent to ${testSend}. zero operatives contacted.`,
          test: {
            recipient: testSend,
            subject: `[TEST] ${subject}`,
            from: BROADCAST_FROM,
            resend_id: sendData.id || null
          },
          network: {
            total_operatives: operatives.length,
            note: 'no operatives were contacted. test isolated to specified address only.'
          },
          verification: {
            check_inbox: testSend,
            check_spam: 'if not in inbox, check spam/promotions folder.',
            verify_rendering: 'open on gmail, apple mail, and outlook to confirm layout.',
            subject_prefix: '[TEST] tag added to distinguish from live broadcast.'
          },
          timestamp: new Date().toISOString()
        });

      } catch (err) {
        return res.status(500).json({
          status: 'test_failed',
          message: 'test transmission disrupted.',
          error: err.message,
          timestamp: new Date().toISOString()
        });
      }
    }

    // ── Send in batches of 50 (Resend rate limit) ──
    const BATCH_SIZE = 50;
    const BATCH_DELAY = 1100; // just over 1s between batches
    let sent = 0;
    let failed = 0;
    const errors = [];

    for (let i = 0; i < operatives.length; i += BATCH_SIZE) {
      const batch = operatives.slice(i, i + BATCH_SIZE);

      const results = await Promise.allSettled(
        batch.map(async (op) => {
          const html = generateEmail(op.email, op.id);

          const sendRes = await fetch('https://api.resend.com/emails', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${RESEND_API_KEY}`,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              from: BROADCAST_FROM,
              to: [op.email],
              subject: subject,
              html: html,
              text: `ARCHIVE UNLOCKED. Suppression protocols neutralized. Access: https://awsum.ai/archive — Operative ${op.email}, Clearance Level 7.`,
              headers: {
                'X-Entity-Ref-ID': `awsum-broadcast-${op.id}-${Date.now()}`
              },
              tags: [
                { name: 'campaign', value: 'archive-unlock' },
                { name: 'operative_id', value: String(op.id) }
              ]
            })
          });

          if (!sendRes.ok) {
            const errBody = await sendRes.text();
            throw new Error(`${op.email}: ${errBody}`);
          }

          return op.email;
        })
      );

      results.forEach((r) => {
        if (r.status === 'fulfilled') sent++;
        else {
          failed++;
          errors.push(r.reason?.message || 'unknown error');
        }
      });

      // Rate limit pause between batches
      if (i + BATCH_SIZE < operatives.length) {
        await new Promise(resolve => setTimeout(resolve, BATCH_DELAY));
      }
    }

    return res.status(200).json({
      status: 'transmitted',
      message: `broadcast complete. ${sent} signals transmitted. ${failed} lost.`,
      sent,
      failed,
      total: operatives.length,
      errors: errors.length > 0 ? errors.slice(0, 20) : undefined,
      timestamp: new Date().toISOString()
    });

  } catch (err) {
    console.error('Broadcast error:', err);
    return res.status(500).json({
      status: 'error',
      message: 'broadcast transmission disrupted.',
      detail: err.message
    });
  }
}