// Vercel Serverless Function — /api/recruit
// Stores operative emails to Supabase (or any Postgres)
// 
// Required env vars in Vercel dashboard:
//   SUPABASE_URL     — your Supabase project URL
//   SUPABASE_KEY     — your Supabase anon/service key
//
// Supabase table SQL:
//   CREATE TABLE operatives (
//     id BIGSERIAL PRIMARY KEY,
//     email TEXT UNIQUE NOT NULL,
//     ip TEXT,
//     user_agent TEXT,
//     created_at TIMESTAMPTZ DEFAULT NOW()
//   );
//   CREATE INDEX idx_operatives_email ON operatives(email);

export default async function handler(req, res) {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SUPABASE_KEY = process.env.SUPABASE_KEY;

  if (!SUPABASE_URL || !SUPABASE_KEY) {
    return res.status(500).json({ 
      status: 'error', 
      message: 'backend not configured. signal stored locally.' 
    });
  }

  // GET — return operative count
  if (req.method === 'GET') {
    try {
      const response = await fetch(
        `${SUPABASE_URL}/rest/v1/operatives?select=id&limit=0`,
        {
          headers: {
            'apikey': SUPABASE_KEY,
            'Authorization': `Bearer ${SUPABASE_KEY}`,
            'Prefer': 'count=exact'
          }
        }
      );
      const count = parseInt(response.headers.get('content-range')?.split('/')[1] || '0');
      return res.status(200).json({ status: 'ok', count });
    } catch (err) {
      return res.status(500).json({ status: 'error', message: 'network fault. count unavailable.' });
    }
  }

  // POST — register new operative
  if (req.method === 'POST') {
    const { email } = req.body || {};

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ 
        status: 'rejected', 
        message: 'malformed signal. valid frequency required.' 
      });
    }

    const sanitizedEmail = email.toLowerCase().trim();

    try {
      // Check for duplicate
      const checkRes = await fetch(
        `${SUPABASE_URL}/rest/v1/operatives?email=eq.${encodeURIComponent(sanitizedEmail)}&select=id`,
        {
          headers: {
            'apikey': SUPABASE_KEY,
            'Authorization': `Bearer ${SUPABASE_KEY}`
          }
        }
      );
      const existing = await checkRes.json();
      
      if (existing.length > 0) {
        return res.status(409).json({ 
          status: 'duplicate', 
          message: 'frequency already indexed in the network.' 
        });
      }

      // Insert new operative
      const ip = req.headers['x-forwarded-for'] || req.headers['x-real-ip'] || 'unknown';
      const userAgent = req.headers['user-agent'] || 'unknown';

      const insertRes = await fetch(
        `${SUPABASE_URL}/rest/v1/operatives`,
        {
          method: 'POST',
          headers: {
            'apikey': SUPABASE_KEY,
            'Authorization': `Bearer ${SUPABASE_KEY}`,
            'Content-Type': 'application/json',
            'Prefer': 'return=representation'
          },
          body: JSON.stringify({
            email: sanitizedEmail,
            ip: ip.split(',')[0].trim(),
            user_agent: userAgent
          })
        }
      );

      if (!insertRes.ok) {
        const errText = await insertRes.text();
        throw new Error(errText);
      }

      // Get updated count
      const countRes = await fetch(
        `${SUPABASE_URL}/rest/v1/operatives?select=id&limit=0`,
        {
          headers: {
            'apikey': SUPABASE_KEY,
            'Authorization': `Bearer ${SUPABASE_KEY}`,
            'Prefer': 'count=exact'
          }
        }
      );
      const count = parseInt(countRes.headers.get('content-range')?.split('/')[1] || '0');

      return res.status(201).json({ 
        status: 'registered', 
        count,
        message: 'operative logged. encrypted briefing inbound.' 
      });

    } catch (err) {
      console.error('Recruit error:', err);
      return res.status(500).json({ 
        status: 'error', 
        message: 'transmission disrupted. try again.' 
      });
    }
  }

  return res.status(405).json({ status: 'error', message: 'method not recognized.' });
}